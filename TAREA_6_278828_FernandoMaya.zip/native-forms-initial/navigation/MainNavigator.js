import React from "react";
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import LoginScreen from "../Screens/LoginScreen";
import MapScreen from "../Screens/MapScreen";
import LocationMap from "../Screens/LocationMap";
import FormScreen from "../Screens/FormScreen";
import LocationEnded from "../Screens/LocationEnded";
import { createStackNavigator } from '@react-navigation/stack';
import Boton from "../Screens/Logout";
const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

export const MyDrawer = () =>{
    return (
        <Drawer.Navigator>
            <Drawer.Screen name="Maps" component={MapScreen} />
            <Drawer.Screen name="LocationMap" component={LocationMap}/>
            <Drawer.Screen name="LocationEnded" component={LocationEnded}/>
            <Drawer.Screen name="FormScreen" component={FormScreen} />
            <Drawer.Screen name="Logout" component={Boton} />
        </Drawer.Navigator>
    );
}
export const StackLogin = () =>{

    return(
        <Stack.Navigator>
            <Stack.Screen name={"LoginScreen"}
                            component={LoginScreen}
                            options={{headerShown:false}}
            />
        </Stack.Navigator>
    )
}