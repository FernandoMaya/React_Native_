export const LOGIN = 'LOGIN';

export const tryLogin = (user, password) =>{
    if(user === "Fernando" && password === "Maya"){
        return {
            type: LOGIN, //action.type  //payload
            user:user //action.user
        }
    }else{
        throw ("Usuario y/o Contraseña invalidos")
    }

}
export const Salir  =() =>{
    return{
        type: LOGOUT,
    }
}
/*
export const tryLoginServer = (user, password) =>{

    return async (dispatch) => {
        const response = await fetch(endpoint,{
            method:'GET'
        })
        const resData = await response.json();

        if(resData.validation){
            dispatch({
                type: LOGIN, //action.type  //payload
                user:user //action.user
            })
        }else{
            throw ("Usuario y/o Contraseña invalidos")
        }

    }

}
*/