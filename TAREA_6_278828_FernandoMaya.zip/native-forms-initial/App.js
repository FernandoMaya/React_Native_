import React from 'react';
import ReduxThunk from 'redux-thunk';
import {Provider} from 'react-redux';
import LoginValidation from "./navigation/LoginNavigation";
import { createStore, combineReducers, applyMiddleware} from 'redux';
import authReducer from "./store/reducers/authReducer";

export default function App() {
  const rootReducer = combineReducers({
    // cart: cartReducer,
    auth: authReducer,
  })
  const store = createStore(
    rootReducer,
    // window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__(),
    applyMiddleware(ReduxThunk)
  )
  return (
      <Provider store={store}>
            <LoginValidation/>
      </Provider>
  );
}