import React,{useState} from 'react';
import {StyleSheet, View, TextInput, Button, Alert} from "react-native";
import {useDispatch} from "react-redux";
import * as authActions from "../store/actions/authActions";

const LoginScreen = (props) =>{
    const [user, setUser] = useState(null)
    const [password, setPassword] = useState(null)
    const dispatch = useDispatch();
    const onClick = () =>{
        try {
            console.log(user, password)
            user && password ?
                dispatch(authActions.tryLogin(user, password))
            :
                Alert.alert("Error", "Campos vacios", [{text:'ok'}])
        }catch(e){
            Alert.alert("Error", e.toString(), [{text:'ok'}])
        }
    }
    const validateUser = (user) =>{
        console.log(user)
        setUser(user)
    }
    const validatePassword = (password) =>{
        console.log(password)
        setPassword(password)
    }
    return(
        <View style={styles.container}>
            <TextInput
                style={styles.input}
                placeholder={"User"}
                onChangeText={txt => validateUser(txt)}
            />
            <TextInput
                style={styles.input}
                placeholder={"Password"}
                onChangeText={txt => validatePassword(txt)}
            />
            <Button title={"Login"} onPress={onClick}/>
        </View>
    )
}
export default LoginScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding:10,
        justifyContent: 'center',
        alignItems: 'center'
    },
    input: {
        borderColor:'red',
        width:'100%',
        borderWidth:1
    }
});
