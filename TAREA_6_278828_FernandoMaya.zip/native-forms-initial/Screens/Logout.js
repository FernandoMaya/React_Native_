import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity, NativeModules, Alert}   from "react-native";


const CerrarSesion = () => {
    NativeModules.DevSettings.reload();
    Alert.alert("Sesión Cerrada", "", [{ text: 'ok' }])
}

const Boton = () =>{
    return (
        <View style = { styles.container } >
            <TouchableOpacity style={styles.login_btn}>
                <Text style={{ fontSize: 18, color: 'white' }} onPress={CerrarSesion}>
                    Cerrar Sesion
                </Text>
            </TouchableOpacity>
        </View>
    )
}
export default Boton;

const styles = StyleSheet.create({
    container: {   
        flex: 1,
        backgroundColor: '#fff',  
        alignItems: 'center',    
        justifyContent: 'center',  
        flexDirection: 'column', 
    },
    login_btn: {
        backgroundColor: 'lightskyblue', 
        width: 170,
        height: 55,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5
    }
})
