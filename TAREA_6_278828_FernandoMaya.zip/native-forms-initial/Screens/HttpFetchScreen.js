import React, { useState } from "react";
import { View, Alert, TextInput, StyleSheet, Dimensions, Button, Platform } from "react-native";
import DateTimePicker from '@react-native-community/datetimepicker';

let defaultImg = 'https://avalos.sv/wp-content/uploads/default-featured-image.png'

const HttpFetchScreen = ()=>{
    
    const[img, setImg] = useState(defaultImg);

    const [date, setDate] = useState(new Date(1598051730000));
    const [mode, setMode] = useState('date');
    const [show, setShow] = useState(false);
    const onChange = (event, selectedDate) => {
        const currentDate = selectedDate || date;
        setShow(Platform.OS === 'ios');
        setDate(currentDate);
      };

      const fetchNasa = async ()=>{
          const endpoint = ""
          const response = await fetch(endpoint,{
              method:'GET',
              headers:{
                  'Content-Type':'aplication/json'
              }
          })
      }
    
    return(
        <View style ={styles.container}>
            <Image style = {styles.image} source={{uri:img}}/>
            {show && (
                <DateTimePicker
                testID="dateTimePicker"
                value={date}
                mode={mode}
                is24Hour={true}
                display="default"
                onChange={onChange}
                />
            )}
            <Button onPress={showDatepicker} title="Show date picker!" />
            <Text>

            </Text>
        </View>
    )
}
export default HttpFetchScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    image:{
        width:Dimensions.get('window').width,
        height:Dimensions.get('window').height*85,
    },
})