import React, { useState } from "react";
import { View, Alert, TextInput, StyleSheet, Dimensions } from "react-native";
import MapView, { Marker } from "react-native-maps";
import * as Location from "expo-location";

const defaultLocation = {
    latitude: 20.5931,
    longitude: -100.392,
    latitudeDelta: 0.00422,
    longitudeDelta: 0.00421,
}
const LocationEnded = () => {
  
    const [coords, setCoords] = useState(null);
    const [value, onChangeText] = useState('');
    const [value1, onChangeText1] = useState('');
    const [value2, onChangeText2] = useState('');
    const [value3, onChangeText3] = useState('');
    const [value4, onChangeText4] = useState('');
  
    const addMarker = async (event) => {
        setCoords(event.nativeEvent.coordinate)
        await getAddressInfo(event.nativeEvent.coordinate)
    }
    const getAddressInfo = async (coords) => { // Coords de tipo Marker
        try {
            let addressInfo = await Location.reverseGeocodeAsync({
                latitude: coords.latitude,
                longitude: coords.longitude
                
            })
            onChangeText(addressInfo[0].country)
            onChangeText1(addressInfo[0].region)
            onChangeText2(addressInfo[0].city)
            onChangeText3(addressInfo[0].postalCode)
            onChangeText4(addressInfo[0].street)
           
            
        } catch (e) {
            Alert.alert("Error", "Ocurrio un error " + e.toString(), [{ text: 'ok' }])
        }
        
    }
    /*
    const [location, setLocation] = useState(null);
    let location = await Location.getCurrentPositionAsync({});
    setLocation(location);
*/
    return (
        <View style={styles.container}>
            <MapView
                style={styles.map}
                initialRegion={defaultLocation}
                onPress={addMarker}
            >
                {
                    coords ?
                        <Marker key={1} coordinate={coords} /> //coordinate: coordenada del marcador
                      
                        :
                        null
                    
                }
                
            </MapView>
            <View style = {styles.inputContainer}>
                <TextInput
                    style={styles.input}
                    placeholder={"Pais"}
                    onChangeText={onChangeText}
                    value={'' + value} //valor del texinput escrito
                    keyboardType={"default"}
                />
                <TextInput
                    style={styles.input}
                    placeholder={"Estado"}
                    onChangeText={onChangeText1}
                    value={'' + value1}
                    keyboardType={"default"}
                />
                <TextInput
                    style={styles.input}
                    placeholder={"Municipio"}
                    onChangeText={onChangeText2}
                    value={'' + value2}
                    keyboardType={"default"}
                />
                <TextInput
                    style={styles.input}
                    placeholder={"Codigo Postal"}
                    onChangeText={onChangeText3}
                    value={'' + value3}
                    keyboardType={"default"}
                />
                <TextInput
                    style={styles.input}
                    placeholder={"Calle"}
                    onChangeText={onChangeText4}
                    value={'' + value4}
                    keyboardType={"default"}
                />
            </View>
        </View>
    );
}

export default LocationEnded;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    map: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height*0.45,
    },
    inputContainer:{
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
    },
    input:{
        height:40,
        width: '100%',
        margin:5,
        borderWidth:1,
        padding:10,
        borderColor:'red'

    }
});

