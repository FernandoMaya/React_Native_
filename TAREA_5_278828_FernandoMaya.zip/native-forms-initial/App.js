import React from 'react';
import {MyDrawer} from "./navigation/MainNavigator";

export default function App() {
  return (
      <MyDrawer/>
  );
}
