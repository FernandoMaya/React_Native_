import React from "react";
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';

import MapScreen from "../Screens/MapScreen";
import LocationMap from "../Screens/LocationMap";
import FormScreen from "../Screens/FormScreen";
import LocationEnded from "../Screens/LocationEnded";

const Drawer = createDrawerNavigator();

export const MyDrawer = () =>{
    return (
        <NavigationContainer>
            <Drawer.Navigator>
                <Drawer.Screen name="Maps" component={MapScreen} />
                <Drawer.Screen name="LocationMap" component={LocationMap}/>
                <Drawer.Screen name="LocationEnded" component={LocationEnded}/>
                <Drawer.Screen name="FormScreen" component={FormScreen} />
            </Drawer.Navigator>
        </NavigationContainer>
    );
}