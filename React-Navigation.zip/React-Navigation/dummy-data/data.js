export const PRODUCTS =[
    {
        id: 1,
        name:"PS4",
        cost:999,
        description:"PS4 es un sistema de entretenimiento digital y la cuarta consola de sobremesa desarrollada por Sony Computer Entertainment.",
        imgUrl:'https://farm9.staticflickr.com/8132/29536240375_1eeb76fd86_z.jpg',
        
    },
    {
        id: 2,
        name:"XBOX X",
        cost:999,
        description:"Xbox Series X incorpora 16 GB de tipo GDDR6, una memoria principal que se comunica con el SoC a través de un bus de 320 bits.",
        imgUrl:'https://i.blogs.es/1756e3/xbox-series-x/1366_2000.jpeg',
    },
    {
        id: 3,
        name:"SWITCH",
        cost:999,
        description:"Nintendo considera a Switch una consola híbrida. Se puede utilizar como consola de sobremesa con la unidad principal insertada en una estación de acoplamiento para conectarla con un televisor.",
        imgUrl:'https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/media/image/2021/03/nintendo-switch-2255469.jpg',
    },
    {
        id: 4,
        name:"WII U",
        cost:999,
        description:"Wii U es la nueva consola doméstica de Nintendo, una consola que cambia radicalmente la relación que tienes con tu televisor y la forma en la que te conectas con tus amigos y familiares.",
        imgUrl:'https://cdn02.nintendo-europe.com/media/images/10_share_images/systems_11/wii_u_11/H2x1_generic_WiiU_image1280w.jpg',
    },
    {
        id: 5,
        name:"STEAM DECK",
        cost:999,
        description:"La consola portátil de Valve es un ordenador en miniatura cuyos componentes internos prometen tanto o más como su enormísimo catálogo de juegos disponibles.",
        imgUrl:'https://i.blogs.es/12f2bf/screenshot_5243/450_1000.jpeg',
    }
]
// export default data;