import { FontAwesome } from '@expo/vector-icons';
import React,{useState} from 'react';
// import { StyleSheet, Text, View} from 'react-native';
import TabNavigator from "./navigation/AppNavigation";
import * as Font from "expo-font";
import AppLoading from 'expo-app-loading';
import StackNavigator from './navigation/AppNavigation';

export default function App() {
  const [fontLoaded, setFontLoaded] = useState(false);

  const fetchFonts = ()=>{
    return Font.loadAsync({
      'roboto-italic': require('./assets/fonts/Roboto-Italic.ttf'),
      'roboto-bold': require('./assets/fonts/Roboto-Bold.ttf'),
      'roboto-thin': require('./assets/fonts/Roboto-Thin.ttf'),
    })
  }
  if(!fontLoaded){
    return(
      <AppLoading
        startAsync={fetchFonts}
        onFinish = {()=> setFontLoaded(true)}
        onError = {console.warn}
      />
    )
  }
  return (
      <StackNavigator/>
  );
}