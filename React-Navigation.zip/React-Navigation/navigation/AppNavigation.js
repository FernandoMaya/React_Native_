import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import React from 'react';
import { AntDesign } from '@expo/vector-icons';
import { EvilIcons } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';
import HomeScreen from "../screens/HomeScreen";
import CartScreen from "../screens/CartScreen";
import DetailsScreen from "../screens/DetailsScreen";
import ProductDetailsScreen from '../screens/ProductDetailsScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

const TabNavigator = () =>{
    return(
        
            <Tab.Navigator>
                <Tab.Screen name="Home" component={HomeScreen} options={{
                    tabBarIcon:({focused})=><AntDesign name="home" size={24} color={focused?"green":"grey"} />
                }}/>
                <Tab.Screen name="Cart" component={CartScreen} options={{
                    tabBarIcon:({focused})=><EvilIcons name="cart" size={24} color={focused?"green":"grey"}/>
                }}/>
                <Tab.Screen name="Details" component={DetailsScreen} options={{
                    tabBarIcon:({focused})=><MaterialIcons name="details" size={24} color={focused?"green":"grey"}/>
                }}/>
            </Tab.Navigator>
    )
}
const StackNavigator = ()=>{
    return (
        <NavigationContainer>
            <Stack.Navigator>
                <Stack.Screen name = {"TabNavigator"}
                component = {TabNavigator}
                options = {{headerShown:false}}    
            />
                <Stack.Screen name = {"ProductDetails"}
                component = {ProductDetailsScreen}    
            />
            </Stack.Navigator>
        </NavigationContainer>
    )
}
export default StackNavigator;