import React from 'react';
import {StyleSheet, View, FlatList, Button, Dimensions} from "react-native";
import {PRODUCTS} from "../dummy-data/data";
import ProductCard from "../componentes/ProductCard";

const HomeScreen = (props) =>{
    // console.log(props)

    return(
        <View style={styles.container}>
            <View style = {styles.listContainer}>
                <FlatList
                    data={PRODUCTS}
                    showsVerticalScrollIndicator ={false}
                    keyExtractor={item => item.id.toString()}
                    renderItem={itemData =>(
                    <ProductCard {...props} productInfo = {itemData.item}/>
                    )}
                />
            </View>
            {/* <Button title={"Redirect"}/> */}
        </View>
    )
}
export default HomeScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
    },
    listContainer:{
        height: Dimensions.get('window').height * 0.825,
        width: '100%',
    }
});
