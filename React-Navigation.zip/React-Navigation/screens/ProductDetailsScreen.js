import React from 'react';
import { StyleSheet, Text, View, Image, Dimensions, Button } from 'react-native';

const ProductDetails = (props)=>{
    const {productInfo} = props.route.params
    return(
        <View style = {styles.card}>
            <Image style={styles.image}
                    source={{uri:productInfo.imgUrl}}/>
            <Text style = {styles.nombre}>
                {productInfo.name}
            </Text>
            <Text style = {styles.desc}>
                {productInfo.description}
            </Text>
            <Text style = {styles.precio}>
                Por un precio de ${productInfo.cost}
            </Text>
            <View style={styles.fixToText}>
        <Button
            style = {{fontSize: 10}}
          title="AGREGAR AL CARRITO"
        />
        <Button
            style = {{fontSize: 10}}
          title="QUITAR DEL CARRITO"
        />
      </View>
            
        </View>
    )
}

export default ProductDetails;

const styles = StyleSheet.create({
    card: {
        marginTop: 30,
        width:'95%',
        marginHorizontal: '2.5%',
        height: Dimensions.get('window').height * 0.90,
        borderRadius: 15,
        overflow: 'hidden',
        backgroundColor: '#fffafa',
        marginBottom:15,
        
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,

        elevation: 5,
    },
    image: {
        width:'100%',
        height: '40%',
        paddingHorizontal: 15,
    },
    nombre:{
        fontFamily: 'roboto-bold',
        fontSize: 25,
        marginTop: 10,
        paddingHorizontal: 15,
    },
    desc:{
        fontFamily: 'roboto-thin',
        fontSize: 18,
        marginTop: 25,
        paddingHorizontal: 15,
    },
    precio:{
        fontFamily: 'roboto-bold',
        fontSize: 18,
        marginTop: 25,
        paddingHorizontal: 15,
    },
    fixToText: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 15,
        paddingVertical: 40,
      },
});