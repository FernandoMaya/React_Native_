import React from 'react';
import {StyleSheet, View, Text, Image, Dimensions} from "react-native";
import TouchableCmp from './UI/TouchableCmp';

const ProductCard = (props) =>{
    const redirect = () =>{
        props.navigation.navigate('ProductDetails', {productInfo:props.productInfo});
    }
    return(
        
        <View style={styles.card}>
            <TouchableCmp onPress = {redirect}>
                <View style = {{height:'100%', width:'100%'}}>
                    <Image style={styles.image}
                    source={{uri:props.productInfo.imgUrl}}/>
                    <Text style = {styles.text}> {props.productInfo.name} </Text>
                </View>
                
            </TouchableCmp>
        </View>
        
        
        
    )
}

export default ProductCard;

const styles = StyleSheet.create({
    card: {
        width:'95%',
        marginHorizontal: '2.5%',
        height: Dimensions.get('window').height * 0.25,
        borderRadius: 15,
        overflow: 'hidden',
        backgroundColor: '#fffafa',
        marginBottom:15,
        
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,

        elevation: 5,

    },
    image: {
        width:'100%',
        height: '70%',
    },
    text:{
        alignContent: 'center',
        fontFamily:'roboto-bold',
        fontSize: 16
    }
});
