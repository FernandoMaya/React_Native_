import React,{useState} from 'react';
import { StyleSheet, Text, View, Modal, TextInput, Button } from 'react-native';

const NoteText = (props) =>{
    return(
        <View style = {styles.container}>
            <Text style = {styles.text}>
                {props.itemData}
            </Text>
            <Button style = {styles.button} color = "#FF6347" title={"Eliminar"}/>
        </View>
    ) 
}

export default NoteText;

const styles = StyleSheet.create({
    text:{
        color: "black",
        textAlign: 'left',
        padding: 3,
        marginLeft: 5,
        marginRight: 10
    },
    container:{
        flexDirection:'row',
        textAlign: 'left',
        alignItems:"flex-start",
        marginBottom: 5,
        justifyContent: 'space-between'
    },
    button:{
        textAlign: 'left',
        padding: 3,
        marginLeft: 50,
        width: 50
    },
});