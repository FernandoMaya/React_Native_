import React,{useState} from 'react';
import { StyleSheet, Text, View, Modal, TextInput, Button } from 'react-native';
const NoteInput = (props) =>{

    const[newNote, setNewNote] = useState('');
    
    const inputhandler = (text) =>{
        setNewNote(text);
    }
    
    const saveNote = () =>{
        props.onsaveNote(newNote)
        setNewNote('')
    }
    return(
        <Modal visible = {props.visible} animationType = "slide">
            <View style = {styles.container}>
                <Text>Soy un Modal</Text>
                <TextInput
                    placeholder = "Ingresa una nota"
                    style = {styles.inputTxt}
                    onChangeText = {inputhandler}
                />
                <View style = {styles.buttonContainer}>

                    <View style = {styles.button}>
                        <Button title = "Cancelar" color = "#FF6347" onPress = {props.onCancel}/>
                    </View>

                    <View style = {styles.button}>
                        <Button title = "Agregar" color = "#7FFFD4" onPress = {saveNote}/>
                    </View>

                </View>
            </View>
        </Modal>
    )
}

export default NoteInput;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
    },
    inputTxt:{
        width: '80%',
        borderColor:'black',
        borderWidth: 1,
        padding: 10,
        marginBottom: 10, 
    },
    ButtonContainer:{
        flexDirection:'row',
        justifyContent:'space-between',
        width: 60,
    },
    button:{
        marginTop: 10,
        width:100,
    }
})