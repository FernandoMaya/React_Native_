import { StatusBar } from 'expo-status-bar';
import React,{useState} from 'react';
import { StyleSheet, Text, View, Button, FlatList } from 'react-native';
import NoteInput from './componentes/NoteInput';
import NoteText from "./componentes/NoteText";

const App = () => {

    const [active, setActive] = useState(false);

    const [notes, setNotes] = useState([]);

    const showModal = ()=>{
        setActive(true);
    }
    const hideModal = () =>{
        setActive(false);
    }
    const addNewNote = (text) =>{
        console.log("Guardando...", text);
        setNotes([... notes, {id:Math.random().toString(), nota:text}]);
        setActive(false)
    }
    console.log(notes);
    return (
        <View style = { styles.container } >
            <Text style = {styles.text}>App Notas!</Text>
            <Button title ="Nueva Nota" color = "#00CED1" onPress = {showModal}/>
            <NoteInput visible={active} onCancel = {hideModal} onsaveNote = {addNewNote}/>
            <View>
                <FlatList style = {styles.notas}
                    keyExtractor={item => item.id}
                    data = {notes}
                    renderItem={itemData =>(
                        <NoteText itemData = {itemData.item.nota}/>
                    )}
                />
            </View>
        </View>
    );
}
export default App;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FA8072',
        alignItems: 'center',
        justifyContent: 'center',
        paddingTop: 200,
    },
    text:{
        color:'#00FF7F',
        fontSize: 40,
        marginBottom: 15
    },
    notas:{
        marginTop:40
    }
});